import { redirect } from "next/navigation"
import { cookies } from "next/headers"
import Link from "next/link"
import { verifyAdminAuthToken, ADMIN_AUTH_COOKIE } from "@/lib/admin-auth"
import CronManage from "@/components/admin/cron-manage"

export const dynamic = "force-dynamic"

export default async function AdminCronPage() {
  const cookieStore = cookies()
  const adminToken = cookieStore.get(ADMIN_AUTH_COOKIE)?.value
  if (!verifyAdminAuthToken(adminToken)) {
    redirect("/admin")
  }

  return (
    <div className="space-y-8 p-6 md:p-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Kelola Cron Job</h1>
          <p className="text-sm text-muted-foreground">
            Auto expired panel berjalan otomatis sekali sehari. Gunakan tombol jalankan manual untuk testing.
          </p>
        </div>
        <Link href="/admin/affiliate" className="text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground">
          Kembali ke Panel Affiliate
        </Link>
      </div>

      <CronManage />
    </div>
  )
}
