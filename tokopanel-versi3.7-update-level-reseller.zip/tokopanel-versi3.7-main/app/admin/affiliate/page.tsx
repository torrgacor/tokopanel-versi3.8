import { redirect } from "next/navigation"
import { cookies } from "next/headers"
import { getCollections } from "@/lib/affiliate"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import AdminWithdrawQueue from "@/components/admin/withdraw-queue"
import AffiliatesManage from "@/components/admin/affiliates-manage"
import AffiliateCommissionSettings from "@/components/admin/affiliate-commission-settings"
import AffiliateLevelsManager from "@/components/admin/affiliate-levels-manager"
import { formatRupiah } from "@/lib/utils"
import { verifyAdminAuthToken, ADMIN_AUTH_COOKIE } from "@/lib/admin-auth"
import Link from "next/link"

export const dynamic = "force-dynamic"

export default async function AdminAffiliatesPage() {
  const cookieStore = cookies()
  const adminToken = cookieStore.get(ADMIN_AUTH_COOKIE)?.value
  if (!verifyAdminAuthToken(adminToken)) {
    redirect("/admin")
  }

  return (
    <div className="space-y-8 p-6 md:p-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Admin Panel Affiliate</h1>
          <p className="text-sm text-muted-foreground">Kelola akun affiliate, cek status, dan proses penarikan secara manual.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/vouchermts" className="text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground">
            Kelola Voucher
          </Link>
          <Link href="/admin/cron" className="text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground">
            Kelola Cron Job
          </Link>
        </div>
      </div>

      <AffiliateCommissionSettings />

      <AffiliateLevelsManager />

      <AffiliatesManage />

      <AdminWithdrawQueue />
    </div>
  )
}
