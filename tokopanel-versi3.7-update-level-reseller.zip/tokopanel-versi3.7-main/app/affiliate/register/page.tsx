"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { registerAffiliate } from "@/app/actions/affiliate-registration"
import { Loader2, Check, ArrowLeft } from "lucide-react"

export default function AffiliateRegisterPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [registrationData, setRegistrationData] = useState<any>(null)

  const [formData, setFormData] = useState({
    storeName: "",
    email: "",
    ownerName: "",
    phoneNumber: "",
    withdrawMethod: "transfer_bank",
    accountNumber: "",
    accountName: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      withdrawMethod: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const result = await registerAffiliate(formData)

      if (result.success) {
        setRegistrationData(result)
        setIsSuccess(true)
        toast({
          title: "Sukses!",
          description: result.message,
        })
      } else {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Gagal mendaftar affiliate",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isSuccess && registrationData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dark-500 via-dark-700 to-dark-900 flex items-center justify-center p-4">
        <Card className="max-w-md w-full border-dark-300 bg-dark-400">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-green-600 rounded-full flex items-center justify-center">
              <Check className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Registrasi Berhasil!</CardTitle>
            <CardDescription>Tunggu email konfirmasi dari admin</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-dark-500 p-4 rounded-lg space-y-2">
              <div>
                <p className="text-xs text-gray-400">User ID</p>
                <p className="font-mono text-sm font-medium text-white">{registrationData.userId}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Referral Code</p>
                <p className="font-mono text-sm font-medium text-white">{registrationData.referralCode}</p>
              </div>
            </div>

            <div className="bg-blue-900 p-3 rounded-lg">
              <p className="text-sm text-blue-100">
                📧 Email konfirmasi sudah dikirim ke <strong>{formData.email}</strong>. Admin kami akan mereview pendaftaran Anda.
              </p>
            </div>

            <Button onClick={() => router.push("/")} className="w-full bg-blue-600 hover:bg-blue-700">
              Kembali ke Beranda
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-500 via-dark-700 to-dark-900 p-4">
      <div className="max-w-2xl mx-auto pt-8 pb-12">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="mb-6 text-gray-300 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Kembali
        </Button>

        <Card className="border-dark-300 bg-dark-400 shadow-2xl">
          <div className="flex justify-end p-4">
            <Button variant="ghost" onClick={() => router.push('/affiliate/login')}>
              Sudah punya akun? Login
            </Button>
          </div>
          <CardHeader>
            <CardTitle className="text-3xl">Daftar Sebagai Affiliate</CardTitle>
            <CardDescription>
              Bergabunglah dengan program affiliate kami dan dapatkan komisi dari setiap penjualan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Informasi Toko */}
              <div className="space-y-4">
                <h3 className="font-semibold text-white">Informasi Toko</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="storeName" className="text-gray-300">
                      Nama Toko
                    </Label>
                    <Input
                      id="storeName"
                      name="storeName"
                      placeholder="Toko Bot Keren"
                      value={formData.storeName}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ownerName" className="text-gray-300">
                      Nama Pemilik
                    </Label>
                    <Input
                      id="ownerName"
                      name="ownerName"
                      placeholder="John Doe"
                      value={formData.ownerName}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-gray-300">
                      Email
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="affiliate@example.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber" className="text-gray-300">
                      Nomor Telepon
                    </Label>
                    <Input
                      id="phoneNumber"
                      name="phoneNumber"
                      placeholder="62812345678"
                      value={formData.phoneNumber}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Informasi Withdraw */}
              <div className="space-y-4">
                <h3 className="font-semibold text-white">Informasi Penarikan</h3>

                <div className="space-y-2">
                  <Label htmlFor="withdrawMethod" className="text-gray-300">
                    Metode Penarikan
                  </Label>
                  <Select value={formData.withdrawMethod} onValueChange={handleSelectChange} disabled={isLoading}>
                    <SelectTrigger className="bg-dark-500 border-dark-300 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-dark-500 border-dark-300">
                      <SelectItem value="transfer_bank">Transfer Bank</SelectItem>
                      <SelectItem value="e_wallet">E-Wallet (OVO/Dana/Gopay)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="accountNumber" className="text-gray-300">
                      Nomor Rekening / No. HP
                    </Label>
                    <Input
                      id="accountNumber"
                      name="accountNumber"
                      placeholder="123456789"
                      value={formData.accountNumber}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accountName" className="text-gray-300">
                      Nama Rekening / Nama Penerima
                    </Label>
                    <Input
                      id="accountName"
                      name="accountName"
                      placeholder="John Doe"
                      value={formData.accountName}
                      onChange={handleInputChange}
                      disabled={isLoading}
                      className="bg-dark-500 border-dark-300 text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Info Box */}
              <div className="bg-blue-900 p-4 rounded-lg border border-blue-700">
                <p className="text-sm text-blue-100">
                  ℹ️ Setelah mendaftar, akun Anda akan berstatus <strong>Pending</strong> dan menunggu approval dari admin. Anda akan menerima email konfirmasi setelah disetujui.
                </p>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 h-11 text-white font-medium"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Mendaftar...
                  </>
                ) : (
                  "Daftar Sebagai Affiliate"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
