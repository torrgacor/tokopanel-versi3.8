import { getCollections } from "@/lib/affiliate"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { formatRupiah, formatDate } from "@/lib/utils"
import Link from "next/link"

export const dynamic = "force-dynamic"

interface SearchParams {
  type?: string | string[]
  status?: string | string[]
  q?: string | string[]
}

export default async function AffiliateTransactionsPage({ searchParams }: { searchParams?: SearchParams }) {
  const cookieStore = cookies()
  const affiliateUser = cookieStore.get("affiliate_user")?.value
  if (!affiliateUser) {
    redirect("/affiliate/login")
  }

  const { affiliateProfiles, affiliateTransactions, withdrawalRequests } = await getCollections()
  const affiliate = await affiliateProfiles.findOne({ userId: affiliateUser })
  if (!affiliate) redirect("/affiliate/register")

  const typeFilter = Array.isArray(searchParams?.type) ? searchParams?.type[0] : searchParams?.type
  const statusFilter = Array.isArray(searchParams?.status) ? searchParams?.status[0] : searchParams?.status
  const queryFilter = Array.isArray(searchParams?.q) ? searchParams?.q[0] : searchParams?.q

  const commissionTransactions = await affiliateTransactions
    .find({ affiliateId: affiliateUser, type: { $in: ["referral", "purchase", "admin_adjust"] } })
    .sort({ createdAt: -1 })
    .toArray()

  const withdrawTransactions = await withdrawalRequests
    .find({ affiliateId: affiliateUser })
    .sort({ createdAt: -1 })
    .toArray()

  const rows = [
    ...commissionTransactions.map((tx) => ({
      id: tx._id?.toString() || tx.transactionId,
      date: tx.createdAt,
      category: "Komisi",
      type: tx.type === "referral" ? "Referral" : tx.type === "purchase" ? "Penjualan" : "Penyesuaian Admin",
      status: "Selesai",
      amount: tx.commission ?? 0,
      detail: tx.planId ? `Paket: ${tx.planId}` : "",
      reference: tx.transactionId || "",
      proofUrl: "",
      rawType: tx.type,
    })),
    ...withdrawTransactions.map((withdraw) => ({
      id: withdraw._id.toString(),
      date: withdraw.createdAt,
      category: "Withdraw",
      type:
        withdraw.status === "approved"
          ? "Disetujui"
          : withdraw.status === "rejected"
          ? "Ditolak"
          : "Pending",
      status: withdraw.status,
      amount: withdraw.amount,
      detail: `${withdraw.method} • ${withdraw.accountNumber}`,
      reference: withdraw.txId || "",
      proofUrl: withdraw.proof?.url || "",
      rawType: "withdraw",
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  const filteredRows = rows.filter((row) => {
    if (typeFilter && typeFilter !== "all") {
      if (typeFilter === "commission" && row.category !== "Komisi") return false
      if (typeFilter === "withdraw" && row.category !== "Withdraw") return false
      if (typeFilter === "referral" && row.rawType !== "referral") return false
      if (typeFilter === "penjualan" && row.rawType !== "purchase") return false
      if (typeFilter === "adjust" && row.rawType !== "admin_adjust") return false
    }

    if (statusFilter && statusFilter !== "all") {
      if (row.status !== statusFilter) return false
    }

    if (queryFilter) {
      const search = queryFilter.toLowerCase()
      const haystack = `${row.category} ${row.type} ${row.detail} ${row.reference}`.toLowerCase()
      if (!haystack.includes(search)) return false
    }

    return true
  })

  const totals = rows.reduce(
    (acc, row) => {
      if (row.category === "Komisi") {
        acc.totalCommission += row.amount
      } else {
        acc.totalWithdraw += row.amount
      }
      acc.totalCount += 1
      return acc
    },
    { totalCommission: 0, totalWithdraw: 0, totalCount: 0 }
  )

  return (
    <div className="space-y-8 p-6 md:p-10">
      <div>
        <h1 className="text-3xl font-bold mb-2">Riwayat Transaksi Affiliate</h1>
        <p className="text-muted-foreground">Lihat semua komisi, penarikan, dan penyesuaian saldo Anda.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Total Komisi</CardTitle>
            <CardDescription>Semua komisi diterima</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold">{formatRupiah(totals.totalCommission)}</div>
          </CardContent>
        </Card>
        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Total Withdraw</CardTitle>
            <CardDescription>Jumlah yang ditarik</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold">{formatRupiah(totals.totalWithdraw)}</div>
          </CardContent>
        </Card>
        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Jumlah Transaksi</CardTitle>
            <CardDescription>Jumlah semua entry</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold">{totals.totalCount}</div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-wrap gap-2">
          <Button variant={typeFilter === "all" || !typeFilter ? "outline" : "secondary"} size="sm" asChild>
            <Link href="/affiliate/transactions?type=all">Semua</Link>
          </Button>
          <Button variant={typeFilter === "commission" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?type=commission">Komisi</Link>
          </Button>
          <Button variant={typeFilter === "withdraw" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?type=withdraw">Withdraw</Link>
          </Button>
          <Button variant={typeFilter === "referral" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?type=referral">Referral</Link>
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant={statusFilter === "all" || !statusFilter ? "outline" : "secondary"} size="sm" asChild>
            <Link href="/affiliate/transactions?status=all">Semua Status</Link>
          </Button>
          <Button variant={statusFilter === "pending" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?status=pending">Pending</Link>
          </Button>
          <Button variant={statusFilter === "approved" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?status=approved">Disetujui</Link>
          </Button>
          <Button variant={statusFilter === "rejected" ? "secondary" : "outline"} size="sm" asChild>
            <Link href="/affiliate/transactions?status=rejected">Ditolak</Link>
          </Button>
        </div>
      </div>

      <Card className="border border-border bg-card">
        <CardHeader>
          <CardTitle>Detail Transaksi</CardTitle>
          <CardDescription>{filteredRows.length} entri cocok dengan filter saat ini.</CardDescription>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Jenis</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Detail</TableHead>
                <TableHead>Jumlah</TableHead>
                <TableHead>Referensi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRows.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{formatDate(row.date)}</TableCell>
                  <TableCell>{row.category === "Komisi" ? `${row.category} - ${row.type}` : row.category}</TableCell>
                  <TableCell className="capitalize">{row.status}</TableCell>
                  <TableCell>{row.detail}</TableCell>
                  <TableCell className={row.category === "Withdraw" ? "text-red-500" : "text-green-500"}>
                    {row.category === "Withdraw" ? "-" : "+"}{formatRupiah(row.amount)}
                  </TableCell>
                  <TableCell>
                    {row.reference || "-"}
                    {row.proofUrl ? (
                      <>
                        {" "}
                        <a href={row.proofUrl} target="_blank" rel="noopener noreferrer" className="text-primary underline underline-offset-4">
                          Lihat Bukti
                        </a>
                      </>
                    ) : null}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
