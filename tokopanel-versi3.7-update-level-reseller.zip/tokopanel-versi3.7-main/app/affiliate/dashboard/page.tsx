import { getCollections, getAffiliateLevelProgress } from "@/lib/affiliate"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatRupiah } from "@/lib/utils"
import WithdrawForm from "@/components/affiliate/withdraw-form"
import AffiliateStatsCard from "@/components/affiliate/stats-card"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export const dynamic = "force-dynamic"

export default async function AffiliateDashboardPage() {
  const cookieStore = cookies()
  const affiliateUser = cookieStore.get("affiliate_user")?.value
  if (!affiliateUser) {
    redirect("/affiliate/login")
  }

  const { affiliateProfiles, affiliateTransactions, withdrawalRequests } = await getCollections()

  const affiliate = await affiliateProfiles.findOne({ userId: affiliateUser })
  if (!affiliate) redirect("/affiliate/register")
  const affiliateId = affiliate?.userId || "demo-affiliate"

  const commissions = await affiliateTransactions
    .find({ affiliateId, type: { $in: ["referral", "purchase", "admin_adjust"] } })
    .sort({ createdAt: -1 })
    .toArray()

  const withdrawals = await withdrawalRequests.find({ affiliateId }).sort({ createdAt: -1 }).toArray()

  const levelProgress = await getAffiliateLevelProgress(affiliateId).catch(() => null)

  const transactions = [...commissions.map((tx) => ({
    ...tx,
    kind: "commission",
  })),
  ...withdrawals.map((withdraw) => ({
    ...withdraw,
    kind: "withdraw",
  }))]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8)

  return (
    <div className="space-y-8 p-6 md:p-10">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard Affiliate</h1>
        <p className="text-muted-foreground">Kelola akun affiliate Anda dan pantau komisi penjualan</p>
      </div>

      {/* Wallet Section */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Saldo Aktif</CardTitle>
            <CardDescription>Saldo yang tersedia untuk withdraw</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold">{formatRupiah(affiliate?.wallet?.balance ?? 0)}</div>
          </CardContent>
        </Card>

        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Saldo Tertahan</CardTitle>
            <CardDescription>Jumlah yang masih menunggu proses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold">{formatRupiah(affiliate?.wallet?.pending ?? 0)}</div>
            <p className="text-sm text-muted-foreground mt-2">Dalam proses withdraw</p>
          </CardContent>
        </Card>

        <Card className="border border-border bg-card">
          <CardHeader>
            <CardTitle>Status Akun</CardTitle>
            <CardDescription>Informasi status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  affiliate?.status === "active" ? "bg-green-500" : affiliate?.status === "suspended" ? "bg-red-500" : "bg-yellow-500"
                }`}
              ></div>
              <span className="text-lg font-medium capitalize">{affiliate?.status ?? "pending"}</span>
            </div>
            {affiliate?.status === "pending" && (
              <p className="text-sm text-yellow-600 mt-2">⏳ Menunggu approval admin</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border border-border bg-card">
        <CardHeader>
          <CardTitle>Level Affiliate</CardTitle>
          <CardDescription>Progress transaksi referral Anda menuju level berikutnya</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <div>
                <p className="text-lg font-semibold">{levelProgress?.currentLevel?.name ?? "Bronze"}</p>
                <p className="text-sm text-muted-foreground">{levelProgress?.message ?? "Belum ada transaksi referral"}</p>
              </div>
              <span className="shrink-0 rounded-full bg-blue-600/10 px-3 py-1 text-sm font-semibold text-blue-600 dark:text-blue-400">
                Komisi {levelProgress?.activeCommissionPercent ?? 0}%
              </span>
            </div>
            <div className="text-sm font-medium text-muted-foreground">
              {levelProgress?.currentCount ?? 0} / {levelProgress?.targetThreshold ?? "—"} transaksi
            </div>
          </div>
          {levelProgress?.nextLevel ? (
            <div className="space-y-2">
              <Progress value={Math.max(0, Math.min(100, levelProgress.progressPercent || 0))} className="h-3" />
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <span>
                  Naik ke {levelProgress.nextLevel.name} ({levelProgress.nextLevel.commissionPercent}% komisi)
                </span>
                <span>{levelProgress.remainingTransactions} transaksi lagi</span>
              </div>
            </div>
          ) : (
            <p className="text-sm text-green-600">Level maksimal tercapai.</p>
          )}

          {levelProgress?.levels?.length ? (
            <div className="flex flex-wrap gap-2 border-t border-border pt-4">
              {levelProgress.levels.map((lvl) => {
                const isCurrent = lvl.name === levelProgress?.currentLevel?.name
                return (
                  <span
                    key={lvl.name}
                    className={`rounded-lg border px-3 py-1.5 text-xs ${
                      isCurrent
                        ? "border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-semibold"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {lvl.name} • {lvl.threshold} trx • {lvl.commissionPercent}%
                  </span>
                )
              })}
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* Referral Stats Grid */}
      <div className="grid gap-6 lg:grid-cols-5">
        <AffiliateStatsCard
          referralCode={affiliate?.referralCode || ""}
          stats={affiliate?.referralStats || { clicks: 0, conversions: 0, successfulTransactions: 0, totalCommission: 0 }}
          level={{
            name: levelProgress?.currentLevel?.name ?? "Bronze",
            commissionPercent: levelProgress?.activeCommissionPercent ?? 0,
          }}
        />
      </div>

      {/* Management Sections */}
      <div className="grid gap-6 lg:grid-cols-1">
        <WithdrawForm affiliateId={affiliateId} />
      </div>

      {/* Transaction History */}
      <Card className="border border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Riwayat Transaksi</span>
            <Button asChild variant="outline" size="sm">
              <Link href="/affiliate/transactions">
                Lihat Semua <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </CardTitle>
          <CardDescription>Transaksi komisi dan penarikan terbaru</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {transactions.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Belum ada transaksi</p>
              <p className="text-xs text-muted-foreground mt-1">Mulai bagikan link referral Anda untuk mendapatkan komisi</p>
            </div>
          ) : (
            <div className="space-y-2">
              {transactions.map((tx) => {
                const isWithdraw = tx.kind === "withdraw"
                const isCommission = tx.kind === "commission"
                const amount = isCommission ? tx.commission || 0 : tx.amount || 0
                const label = isWithdraw
                  ? tx.status === "pending"
                    ? "Withdraw Pending"
                    : tx.status === "approved"
                    ? "Withdraw Disetujui"
                    : "Withdraw Ditolak"
                  : tx.type === "referral"
                  ? "Komisi Referral"
                  : tx.type === "purchase"
                  ? "Komisi Penjualan"
                  : "Penyesuaian Saldo"
                const amountPrefix = isWithdraw ? "-" : "+"
                const amountClass = isWithdraw ? "text-red-500" : "text-green-500"

                return (
                  <div key={tx._id ?? tx.transactionId} className="rounded-xl border border-border bg-background p-4">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="font-medium">{label}</p>
                          {tx.type === "referral" && (
                            <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">Referral</span>
                          )}
                          {isWithdraw && tx.status === "approved" && (
                            <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">Approved</span>
                          )}
                          {isWithdraw && tx.status === "rejected" && (
                            <span className="text-xs bg-yellow-600 text-white px-2 py-1 rounded">Rejected</span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{new Date(tx.createdAt).toLocaleString("id-ID")}</p>
                        {tx.planId ? <p className="text-sm text-muted-foreground">Paket: {tx.planId}</p> : null}
                        {tx.txId ? <p className="text-sm text-muted-foreground">TxID: {tx.txId}</p> : null}
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${amountClass}`}>{amountPrefix}{formatRupiah(amount)}</p>
                        <p className="text-sm text-muted-foreground">{isWithdraw ? "Penarikan saldo" : "Pendapatan komisi"}</p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Info Box */}
      <Card className="border border-blue-600 bg-blue-50 dark:bg-blue-900">
        <CardContent className="pt-6">
          <div className="space-y-2">
            <h3 className="font-semibold text-blue-900 dark:text-blue-100">💡 Tips Tingkatkan Komisi</h3>
            <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
              <li>✓ Bagikan link referral ke grup WhatsApp, Telegram, atau media sosial Anda</li>
              <li>✓ Buat content yang menarik tentang produk kami</li>
              <li>✓ Sesuaikan harga markup Anda untuk kompetitif namun tetap menguntungkan</li>
              <li>✓ Monitor statistik referral untuk mengetahui channel yang paling efektif</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
