export type PlanAccess = "regular" | "admin"

export interface Plan {
  id: string
  type: "private" | "public"
  access: PlanAccess
  name: string
  memory: number
  disk: number
  cpu: number
  price: number
  description: string
  features: string[]
  durationDays: number
}
/* Ini dokumentasi untuk durationDays (masa aktif nya)
Angka biasa = hari
Angka + h = jam
Angka + m = menit

Contoh:
durationDays: 30, > 30 hari
durationDays: "1h", > 1 jam
durationDays: "1m", > 1 menit 

Variasi durasi nya biar kamu makin mudah testing nya, bisa buat satu plan baru yg durasi nya "1m" misalnya jadi pas transaksi sukses kamu bisa ke admin dashboard > kelola cron dan klik jalankan buat test apakah cron nya bekerja sesuai ekspektasi atau ada error, kalau udh sesuai berarti dah beres, nanti vercel eksekusi cron nya otomatis satu kali sehari (ini limit paket gratis vercel)
*/

export const plans: Plan[] = [
  // Private Plans - Regular Access
  {
    id: "1gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 1GB",
    memory: 1025,
    disk: 1025,
    cpu: 45,
    price: 2000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗥𝗶𝗻𝗴𝗮𝗻 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗥𝗶𝗻𝗴𝗮𝗻",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "1,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 1,5GB",
    memory: 1525,
    disk: 1525,
    cpu: 65,
    price: 3000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗥𝗶𝗻𝗴𝗮𝗻 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗥𝗶𝗻𝗴𝗮𝗻",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "2gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 2GB",
    memory: 2025,
    disk: 2025,
    cpu: 85,
    price: 4000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗥𝗶𝗻𝗴𝗮𝗻",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "2,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 2,5GB",
    memory: 2525,
    disk: 2525,
    cpu: 105,
    price: 5000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗥𝗶𝗻𝗴𝗮𝗻",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "3gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 3GB",
    memory: 3025,
    disk: 3025,
    cpu: 125,
    price: 6000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "3,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 3,5GB",
    memory: 3525,
    disk: 3525,
    cpu: 145,
    price: 7000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "4gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 4GB",
    memory: 4025,
    disk: 4025,
    cpu: 165,
    price: 8000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "4,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 4,5GB",
    memory: 4525,
    disk: 4525,
    cpu: 185,
    price: 9000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 5GB",
    memory: 5025,
    disk: 5025,
    cpu: 205,
    price: 10000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗠𝗲𝗻𝗲𝗻𝗴𝗮𝗵",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "5,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 5,5GB",
    memory: 5525,
    disk: 5525,
    cpu: 225,
    price: 11000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "6gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 6GB",
    memory: 6025,
    disk: 6025,
    cpu: 245,
    price: 12000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "6,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 6,5GB",
    memory: 6525,
    disk: 6525,
    cpu: 265,
    price: 13000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "7gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 7GB",
    memory: 7025,
    disk: 7025,
    cpu: 285,
    price: 14000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "7,5gb",
    type: "private",
    access: "regular",
    name: "PANEL BOT 7GB",
    memory: 7525,
    disk: 7525,
    cpu: 305,
    price: 15000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },

  // Public Plans - Regular Access
    {
    id: "1gb/unli",
    type: "public",
    access: "regular",
    name: "PANEL BOT 1GB",
    memory: 1025,
    disk: 1025,
    cpu: 0,
    price: 9500,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗛𝗲𝗺𝗮𝘁 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗥𝗶𝗻𝗴𝗮𝗻",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "2gb/unli",
    type: "public",
    access: "regular",
    name: "PANEL BOT 2GB",
    memory: 2025,
    disk: 2025,
    cpu: 0,
    price: 10500,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗛𝗲𝗺𝗮𝘁 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗦𝘁𝗮𝗻𝗱𝗮𝗿",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "3gb/unli",
    type: "public",
    access: "regular",
    name: "PANEL BOT 3GB",
    memory: 3025,
    disk: 3025,
    cpu: 0,
    price: 11500,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗛𝗲𝗺𝗮𝘁 𝗨𝗻𝘁𝘂𝗸 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗕𝗲𝗿𝗮𝘁",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },
  {
    id: "unlimited",
    type: "public",
    access: "regular",
    name: "PANEL BOT UNLIMITED",
    memory: 0,
    disk: 0,
    cpu: 0,
    price: 17000,
    durationDays: 30,
    description: "𝗣𝗮𝗸𝗲𝘁 𝗕𝗶𝘀𝗻𝗶𝘀 𝗨𝗻𝘁𝘂𝗸 𝗦𝗲𝗺𝘂𝗮 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁",
    features: ["Akses Panel Bot", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace", "Terlindungi Dari Maling Script"],
  },

  // Public Plans - Admin Access

  // access "admin" = admin panel
  // access "regular" = panel biasa
  {
    id: "adminpanel",
    type: "public",
    access: "admin",
    name: "GA DI JUAL",
    memory: 0,
    disk: 0,
    cpu: 0,
    price: 1000000,
    durationDays: 30,
    description: "𝗞𝗼𝗻𝘁𝗿𝗼𝗹 𝗗𝗮𝗻 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗣𝗮𝗻𝗲𝗹 𝗔𝗻𝗱𝗮 𝗦𝗲𝗻𝗱𝗶𝗿𝗶",
    features: ["Akses Admin Panel", "Membuat Panel Sepuasnya", "Bisa Jualan Panel", "Support Nodejs 20+", "Masa Aktif ±1 Bulan", "Garansi Aktif 30 Hari", "Garansi 5× Replace"],
  },
]
